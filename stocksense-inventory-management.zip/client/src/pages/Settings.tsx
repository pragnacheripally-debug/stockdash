import { FormEvent, useState } from "react";
import { Bell, Check, ChevronDown, Globe2, LockKeyhole, Save, ShieldCheck, UserRound } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";
import { getStoredUser, saveStoredUser } from "@/lib/auth";
import { getActiveWarehouse, saveActiveWarehouse, warehouses } from "@/lib/workspace";

export default function Settings() {
  const user = getStoredUser();
  const [name, setName] = useState(user?.name ?? "Maya Rao");
  const [email, setEmail] = useState(user?.email ?? "maya@company.com");
  const [warehouse, setWarehouse] = useState(() => getActiveWarehouse().name);
  const [notifications, setNotifications] = useState(true);

  const saveProfile = (event: FormEvent) => {
    event.preventDefault();
    saveStoredUser({ name: name.trim() || "Maya Rao", email: email.trim() || "maya@company.com", createdAt: user?.createdAt ?? new Date().toISOString() });
    saveActiveWarehouse(warehouse);
    toast.success("Profile details saved");
  };

  return <div className="module-page settings-page"><header className="module-topbar"><Link href="/" className="module-back">← Dashboard</Link><div className="module-topbar-right"><span className="module-sync"><span /> Settings synced</span><div className="topbar-avatar">{name.slice(0, 2).toUpperCase()}</div></div></header><main className="module-content"><div className="module-crumbs"><span>Manage</span><span>/</span><strong>Settings</strong></div><section className="module-hero"><div><div className="eyebrow"><UserRound size={13} /> Workspace preferences</div><h1>Settings<span className="heading-period">.</span></h1><p>Keep your profile, workspace, and notification preferences up to date.</p></div></section><div className="settings-layout"><section className="module-panel settings-card"><div className="settings-card-header"><div><div className="panel-kicker">Account details</div><h2>Your profile</h2></div><span className="settings-status"><Check size={13} /> Saved locally</span></div><form className="settings-form" onSubmit={saveProfile}><label>Full name<div className="auth-input"><UserRound size={16} /><input value={name} onChange={(event) => setName(event.target.value)} /></div></label><label>Work email<div className="auth-input"><Globe2 size={16} /><input type="email" value={email} onChange={(event) => setEmail(event.target.value)} /></div></label><label>Default warehouse<div className="settings-select"><select value={warehouse} onChange={(event) => setWarehouse(event.target.value)}>{warehouses.map((item) => <option key={item.name}>{item.name}</option>)}</select><ChevronDown size={14} /></div></label><button className="primary-button settings-save" type="submit"><Save size={15} /> Save profile</button></form></section><section className="module-panel settings-card"><div className="settings-card-header"><div><div className="panel-kicker">Workspace controls</div><h2>Preferences</h2></div></div><div className="preference-list"><div className="preference-row"><span className="preference-icon"><Bell size={16} /></span><span><strong>Activity notifications</strong><small>Get updates when stock needs attention.</small></span><button className={`preference-toggle ${notifications ? "on" : ""}`} type="button" onClick={() => setNotifications((value) => !value)} aria-pressed={notifications}><span /></button></div><div className="preference-row"><span className="preference-icon"><LockKeyhole size={16} /></span><span><strong>Security & access</strong><small>Manage sign-in and team permissions.</small></span><button className="text-button" type="button" onClick={() => toast("Security settings are coming soon")}>Manage</button></div><div className="preference-row"><span className="preference-icon"><ShieldCheck size={16} /></span><span><strong>Data protection</strong><small>Your workspace is synced and encrypted.</small></span><span className="protected-badge">Protected</span></div></div></section></div></main></div>;
}
