import { FormEvent, useState } from "react";
import { ArrowRight, Check, Eye, EyeOff, LockKeyhole, Mail, UserRound, Warehouse } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { saveStoredUser } from "@/lib/auth";

export default function Register() {
  const [, navigate] = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "", terms: false });

  const updateField = (field: keyof typeof form, value: string | boolean) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (form.password.length < 8) {
      toast.error("Use at least 8 characters for your password");
      return;
    }
    if (form.password !== form.confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }
    if (!form.terms) {
      toast.error("Please accept the terms to continue");
      return;
    }
    saveStoredUser({ name: form.name.trim(), email: form.email.trim(), createdAt: new Date().toISOString() });
    toast.success("Account created — welcome to StockSense");
    navigate("/");
  };

  return (
    <main className="auth-page">
      <section className="auth-aside">
        <div className="auth-brand">
          <div className="brand-mark"><span /><span /><span /></div>
          <span>stocksense</span>
        </div>
        <div className="auth-aside-copy">
          <div className="eyebrow auth-eyebrow"><span className="live-pulse" /> Inventory operating system</div>
          <h1>Make every movement<br /><em>count.</em></h1>
          <p>Bring your products, locations, and daily operations into one calm, connected workspace.</p>
          <div className="auth-benefits">
            <div><span><Check size={14} /></span><strong>One source of truth</strong><small>See what is moving across every location.</small></div>
            <div><span><Check size={14} /></span><strong>Built for momentum</strong><small>Turn low stock into your next clear action.</small></div>
            <div><span><Check size={14} /></span><strong>Ready for your team</strong><small>Keep everyone aligned from day one.</small></div>
          </div>
        </div>
        <div className="auth-aside-footer">© 2026 StockSense · Inventory, in motion.</div>
      </section>

      <section className="auth-content">
        <div className="auth-mobile-brand">
          <div className="brand-mark"><span /><span /><span /></div><span>stocksense</span>
        </div>
        <div className="auth-card">
          <div className="auth-card-header">
            <div className="auth-kicker"><Warehouse size={14} /> Start your workspace</div>
            <h2>Create your account<span className="heading-period">.</span></h2>
            <p>Set up your StockSense account in less than a minute.</p>
          </div>
          <form className="auth-form" onSubmit={handleSubmit}>
            <label>Full name<div className="auth-input"><UserRound size={16} /><input required autoComplete="name" placeholder="Maya Rao" value={form.name} onChange={(event) => updateField("name", event.target.value)} /></div></label>
            <label>Work email<div className="auth-input"><Mail size={16} /><input required type="email" autoComplete="email" placeholder="maya@company.com" value={form.email} onChange={(event) => updateField("email", event.target.value)} /></div></label>
            <div className="auth-form-row">
              <label>Password<div className="auth-input"><LockKeyhole size={16} /><input required minLength={8} type={showPassword ? "text" : "password"} autoComplete="new-password" placeholder="8+ characters" value={form.password} onChange={(event) => updateField("password", event.target.value)} /><button type="button" className="auth-toggle" onClick={() => setShowPassword((current) => !current)} aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? <EyeOff size={15} /> : <Eye size={15} />}</button></div></label>
              <label>Confirm password<div className="auth-input"><LockKeyhole size={16} /><input required minLength={8} type={showConfirmPassword ? "text" : "password"} autoComplete="new-password" placeholder="Repeat password" value={form.confirmPassword} onChange={(event) => updateField("confirmPassword", event.target.value)} /><button type="button" className="auth-toggle" onClick={() => setShowConfirmPassword((current) => !current)} aria-label={showConfirmPassword ? "Hide password" : "Show password"}>{showConfirmPassword ? <EyeOff size={15} /> : <Eye size={15} />}</button></div></label>
            </div>
            <label className="auth-check"><input type="checkbox" checked={form.terms} onChange={(event) => updateField("terms", event.target.checked)} /><span>I agree to the <button type="button" onClick={() => toast("Terms and privacy details are coming soon")}>terms of service</button> and privacy policy.</span></label>
            <button className="auth-submit" type="submit">Create account <ArrowRight size={16} /></button>
          </form>
          <p className="auth-switch">Already have an account? <button type="button" onClick={() => navigate("/")}>Sign in</button></p>
        </div>
      </section>
    </main>
  );
}
