import { FormEvent, useState } from "react";
import { ArrowRight, LockKeyhole, Mail, Warehouse } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { getStoredUser, saveStoredUser } from "@/lib/auth";

export default function Login() {
  const [, navigate] = useLocation();
  const storedUser = getStoredUser();
  const [email, setEmail] = useState(storedUser?.email ?? "");
  const [password, setPassword] = useState("");

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!email.trim() || password.length < 8) {
      toast.error("Enter your email and an 8+ character password");
      return;
    }
    saveStoredUser({ name: storedUser?.name ?? email.split("@")[0], email: email.trim(), createdAt: storedUser?.createdAt ?? new Date().toISOString() });
    toast.success(`Welcome back${storedUser ? `, ${storedUser.name.split(" ")[0]}` : ""}`);
    navigate("/");
  };

  return (
    <main className="auth-page login-page">
      <section className="auth-aside">
        <div className="auth-brand"><div className="brand-mark"><span /><span /><span /></div><span>stocksense</span></div>
        <div className="auth-aside-copy"><div className="eyebrow auth-eyebrow"><span className="live-pulse" /> Welcome back</div><h1>Keep stock<br /><em>moving.</em></h1><p>Your inventory workspace is ready when you are. Pick up exactly where your team left off.</p><div className="auth-benefits"><div><span>01</span><strong>Live visibility</strong><small>See stock, operations, and exceptions together.</small></div><div><span>02</span><strong>Clear next steps</strong><small>Stay ahead of every reorder and transfer.</small></div></div></div>
        <div className="auth-aside-footer">© 2026 StockSense · Inventory, in motion.</div>
      </section>
      <section className="auth-content"><div className="auth-mobile-brand"><div className="brand-mark"><span /><span /><span /></div><span>stocksense</span></div><div className="auth-card"><div className="auth-card-header"><div className="auth-kicker"><Warehouse size={14} /> Inventory workspace</div><h2>Sign in<span className="heading-period">.</span></h2><p>Use your StockSense account to continue.</p></div><form className="auth-form" onSubmit={handleSubmit}><label>Work email<div className="auth-input"><Mail size={16} /><input required type="email" autoComplete="email" placeholder="maya@company.com" value={email} onChange={(event) => setEmail(event.target.value)} /></div></label><label>Password<div className="auth-input"><LockKeyhole size={16} /><input required minLength={8} type="password" autoComplete="current-password" placeholder="Your password" value={password} onChange={(event) => setPassword(event.target.value)} /></div></label><button className="auth-submit" type="submit">Sign in <ArrowRight size={16} /></button></form><p className="auth-switch">New to StockSense? <button type="button" onClick={() => navigate("/register")}>Create an account</button></p></div></section>
    </main>
  );
}
