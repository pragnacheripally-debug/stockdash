import { FormEvent, useMemo, useState } from "react";
import {
  ArrowLeft,
  ArrowUpRight,
  Boxes,
  Check,
  ChevronDown,
  CircleHelp,
  Filter,
  MapPin,
  Package,
  Plus,
  Search,
  SlidersHorizontal,
  Sparkles,
  X,
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { publishInventoryThreshold } from "@/lib/inventory-events";

type Product = {
  id: number;
  name: string;
  sku: string;
  category: string;
  uom: string;
  stock: number;
  reorder: number;
  location: string;
  status: "Healthy" | "Low stock" | "Out of stock";
  updated: string;
};

const starterProducts: Product[] = [
  { id: 1, name: "Stainless Steel Rods", sku: "STL-ROD-12", category: "Raw materials", uom: "kg", stock: 48, reorder: 120, location: "Main Warehouse", status: "Low stock", updated: "Today, 10:42" },
  { id: 2, name: "Industrial Bearings", sku: "BRG-6204-2Z", category: "Components", uom: "pcs", stock: 14, reorder: 40, location: "Main Warehouse", status: "Low stock", updated: "Today, 09:18" },
  { id: 3, name: "Safety Gloves · L", sku: "PPE-GLV-L", category: "Safety & PPE", uom: "pairs", stock: 26, reorder: 80, location: "Overflow Bay", status: "Low stock", updated: "Yesterday, 16:40" },
  { id: 4, name: "Mild Steel Sheets", sku: "MS-SHT-08", category: "Raw materials", uom: "sheets", stock: 1240, reorder: 500, location: "Main Warehouse", status: "Healthy", updated: "Yesterday, 15:12" },
  { id: 5, name: "Hydraulic Hose 1/2 in", sku: "HYD-HOS-05", category: "Components", uom: "m", stock: 318, reorder: 100, location: "Production Floor", status: "Healthy", updated: "Sep 24, 11:06" },
  { id: 6, name: "Welding Electrodes", sku: "WLD-ELC-6013", category: "Consumables", uom: "boxes", stock: 0, reorder: 24, location: "Main Warehouse", status: "Out of stock", updated: "Sep 23, 14:28" },
  { id: 7, name: "Aluminium Angle 25mm", sku: "ALU-ANG-25", category: "Raw materials", uom: "m", stock: 86, reorder: 50, location: "Overflow Bay", status: "Healthy", updated: "Sep 22, 09:50" },
];

const categories = ["All categories", "Raw materials", "Components", "Safety & PPE", "Consumables"];
const locations = ["All locations", "Main Warehouse", "Overflow Bay", "Production Floor"];

function StatusPill({ status }: { status: Product["status"] }) {
  const styles = { Healthy: "product-status-healthy", "Low stock": "product-status-low", "Out of stock": "product-status-out" };
  return <span className={`product-status ${styles[status]}`}><span />{status}</span>;
}

function ProductIcon({ status }: { status: Product["status"] }) {
  return <span className={`product-icon product-icon-${status.toLowerCase().replace(" ", "-")}`}><Package size={17} /></span>;
}

export default function Products() {
  const [, navigate] = useLocation();
  const [products, setProducts] = useState(starterProducts);
  const [query, setQuery] = useState(() => new URLSearchParams(window.location.search).get("search") ?? "");
  const [category, setCategory] = useState("All categories");
  const [location, setLocation] = useState(() => new URLSearchParams(window.location.search).get("warehouse") ?? "All locations");
  const [stockView, setStockView] = useState(() => new URLSearchParams(window.location.search).get("stock") === "low" ? "Low stock" : "All stock");
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ name: "", sku: "", category: "Raw materials", uom: "kg", stock: "", reorder: "", location: "Main Warehouse" });

  const filteredProducts = useMemo(() => products.filter((product) => {
    const normalizedQuery = query.trim().toLowerCase();
    const skuQuery = normalizedQuery.startsWith("sku:") ? normalizedQuery.slice(4).trim() : "";
    const haystack = `${product.name} ${product.sku} ${product.category} ${product.location}`.toLowerCase();
    const matchesQuery = skuQuery ? product.sku.toLowerCase().includes(skuQuery) : haystack.includes(normalizedQuery);
    const matchesCategory = category === "All categories" || product.category === category;
    const matchesLocation = location === "All locations" || product.location === location;
    const matchesStock = stockView === "All stock" || (stockView === "Low stock" && product.status === "Low stock") || (stockView === "Out of stock" && product.status === "Out of stock") || (stockView === "Healthy" && product.status === "Healthy");
    return matchesQuery && matchesCategory && matchesLocation && matchesStock;
  }), [products, query, category, location, stockView]);

  const resetForm = () => setForm({ name: "", sku: "", category: "Raw materials", uom: "kg", stock: "", reorder: "", location: "Main Warehouse" });

  const createProduct = (event: FormEvent) => {
    event.preventDefault();
    const stock = Number(form.stock || 0);
    const reorder = Number(form.reorder || 0);
    if (!form.name.trim() || !form.sku.trim() || !form.uom.trim()) {
      toast.error("Add a product name, SKU, and unit of measure");
      return;
    }
    const newProduct: Product = { id: Date.now(), name: form.name.trim(), sku: form.sku.trim().toUpperCase(), category: form.category, uom: form.uom, stock, reorder, location: form.location, status: stock === 0 ? "Out of stock" : stock <= reorder ? "Low stock" : "Healthy", updated: "Just now" };
    setProducts((current) => [newProduct, ...current]);
    if (newProduct.status !== "Healthy") {
      publishInventoryThreshold({ name: newProduct.name, sku: newProduct.sku, stock: newProduct.stock, reorder: newProduct.reorder, uom: newProduct.uom, location: newProduct.location, status: newProduct.status });
    }
    setCreateOpen(false);
    resetForm();
    toast.success(`${newProduct.name} added to your catalog`);
  };

  return (
    <div className="module-page">
      <header className="module-topbar">
        <Link href="/" className="module-back"><ArrowLeft size={16} /> Dashboard</Link>
        <div className="module-topbar-right"><span className="module-sync"><span /> Synced just now</span><div className="topbar-avatar">MR</div></div>
      </header>
      <main className="module-content">
        <div className="module-crumbs"><span>Workspace</span><span>/</span><strong>Products</strong></div>
        <section className="module-hero">
          <div><div className="eyebrow"><Boxes size={13} /> Catalog control</div><h1>Products<span className="heading-period">.</span></h1><p>Keep every SKU, stock level, and reorder rule in one place.</p></div>
          <button className="primary-button" onClick={() => setCreateOpen(true)}><Plus size={17} /> Add product</button>
        </section>

        <section className="product-summary-grid">
          <div className="summary-card"><span className="summary-label">Catalog size</span><strong>{products.length + 241}</strong><span className="summary-note"><ArrowUpRight size={13} /> 12 new this month</span></div>
          <div className="summary-card summary-alert"><span className="summary-label">Needs reordering</span><strong>{products.filter((item) => item.status !== "Healthy").length + 15}</strong><span className="summary-note">Across 3 locations</span></div>
          <div className="summary-card"><span className="summary-label">Categories</span><strong>14</strong><span className="summary-note">Raw materials lead · 42%</span></div>
          <div className="summary-card"><span className="summary-label">Tracked units</span><strong>24.6k</strong><span className="summary-note"><Sparkles size={13} /> Live stock valuation ready</span></div>
        </section>

        <section className="module-panel catalog-panel">
          <div className="catalog-header"><div><div className="panel-kicker">Product catalog</div><h2>All products <span>{products.length + 241}</span></h2></div><button className="text-button" onClick={() => toast("Bulk import is coming soon")}>Import catalog <ArrowUpRight size={14} /></button></div>
          <div className="catalog-toolbar"><label className="catalog-search"><Search size={16} /><input placeholder="Search name, SKU, or sku:BRG-6204" value={query} onChange={(event) => setQuery(event.target.value)} aria-label="Search products by name or SKU" /></label><div className="catalog-select"><Filter size={14} /><select value={category} onChange={(event) => setCategory(event.target.value)} aria-label="Filter by category">{categories.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={13} /></div><div className="catalog-select"><MapPin size={14} /><select value={location} onChange={(event) => setLocation(event.target.value)} aria-label="Filter by location">{locations.map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={13} /></div><div className="catalog-select"><SlidersHorizontal size={14} /><select value={stockView} onChange={(event) => setStockView(event.target.value)} aria-label="Filter by stock status"><option>All stock</option><option>Healthy</option><option>Low stock</option><option>Out of stock</option></select><ChevronDown size={13} /></div></div>
          <div className="product-table-wrap"><table className="product-table"><thead><tr><th>Product</th><th>Category</th><th>On hand</th><th>Reorder point</th><th>Location</th><th>Updated</th><th>Status</th><th /></tr></thead><tbody>{filteredProducts.map((product) => <tr key={product.id}><td><div className="product-cell"><ProductIcon status={product.status} /><span><button className="product-name" onClick={() => toast(`${product.name} details opened`)}>{product.name}</button><small>{product.sku}</small></span></div></td><td><span className="category-label">{product.category}</span></td><td><strong className="stock-value">{product.stock.toLocaleString()} <small>{product.uom}</small></strong></td><td><span className="reorder-value">{product.reorder.toLocaleString()} {product.uom}</span></td><td><span className="table-location"><MapPin size={13} />{product.location}</span></td><td><span className="updated-value">{product.updated}</span></td><td><StatusPill status={product.status} /></td><td><button className="row-more" onClick={() => toast(`${product.name} actions opened`)} aria-label={`More actions for ${product.name}`}>•••</button></td></tr>)}</tbody></table>{filteredProducts.length === 0 && <div className="empty-state"><Search size={18} /><strong>No products found</strong><span>Try a different search or filter combination.</span></div>}</div>
          <div className="catalog-footer"><span>Showing <strong>{filteredProducts.length}</strong> of {products.length + 241} products</span><span className="catalog-footer-note"><CircleHelp size={13} /> Stock levels are updated from every receipt, delivery, transfer, and adjustment.</span></div>
        </section>
      </main>

      {createOpen && <div className="drawer-backdrop" onClick={() => setCreateOpen(false)}><section className="quick-drawer product-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-top"><div><div className="panel-kicker accent-kicker">Product catalog</div><h2>Add a product</h2><p>Create a SKU and define its stock rules.</p></div><button className="icon-button" onClick={() => setCreateOpen(false)} aria-label="Close add product form"><X size={18} /></button></div><form className="product-form" onSubmit={createProduct}><label>Product name<input required placeholder="e.g. Stainless Steel Rods" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} /></label><label>SKU / code<input required placeholder="e.g. STL-ROD-12" value={form.sku} onChange={(event) => setForm({ ...form, sku: event.target.value })} /></label><div className="form-row"><label>Category<div className="form-select"><select value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })}>{categories.slice(1).map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={13} /></div></label><label>Unit of measure<input required placeholder="kg" value={form.uom} onChange={(event) => setForm({ ...form, uom: event.target.value })} /></label></div><div className="form-row"><label>Initial stock<input type="number" min="0" placeholder="0" value={form.stock} onChange={(event) => setForm({ ...form, stock: event.target.value })} /></label><label>Reorder point<input type="number" min="0" placeholder="0" value={form.reorder} onChange={(event) => setForm({ ...form, reorder: event.target.value })} /></label></div><label>Default location<div className="form-select"><select value={form.location} onChange={(event) => setForm({ ...form, location: event.target.value })}>{locations.slice(1).map((item) => <option key={item}>{item}</option>)}</select><ChevronDown size={13} /></div></label><div className="form-note"><Sparkles size={14} /><span>The system will automatically flag this product when on-hand stock drops below its reorder point.</span></div><div className="form-actions"><button type="button" className="secondary-button" onClick={() => setCreateOpen(false)}>Cancel</button><button type="submit" className="primary-button"><Check size={16} /> Create product</button></div></form></section></div>}
    </div>
  );
}
