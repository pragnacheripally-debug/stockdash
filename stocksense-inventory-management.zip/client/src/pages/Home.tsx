import { useEffect, useMemo, useState, type KeyboardEvent } from "react";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Bell,
  Boxes,
  ChevronDown,
  CircleHelp,
  ClipboardCheck,
  FileBarChart,
  Filter,
  LayoutDashboard,
  LifeBuoy,
  ListFilter,
  LogOut,
  MapPin,
  Menu,
  Package,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Truck,
  UserRound,
  UsersRound,
  Warehouse,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { clearStoredUser, getStoredUser } from "@/lib/auth";
import { getActiveWarehouse, saveActiveWarehouse, warehouses } from "@/lib/workspace";

type Operation = {
  ref: string;
  type: "Receipt" | "Delivery" | "Transfer" | "Adjustment";
  partner: string;
  location: string;
  date: string;
  status: "Waiting" | "Ready" | "Done" | "Draft";
  units: string;
};

const operations: Operation[] = [
  { ref: "IN/02481", type: "Receipt", partner: "Northstar Metals", location: "Main Warehouse", date: "Today, 10:42", status: "Waiting", units: "+ 1,240" },
  { ref: "OUT/01892", type: "Delivery", partner: "Apex Fabrication", location: "Main Warehouse", date: "Today, 09:18", status: "Ready", units: "− 86" },
  { ref: "INT/00917", type: "Transfer", partner: "Production Floor", location: "Rack A → Line 3", date: "Today, 08:52", status: "Done", units: "340" },
  { ref: "ADJ/00108", type: "Adjustment", partner: "Cycle count · Ana Ruiz", location: "Overflow Bay", date: "Yesterday, 16:40", status: "Done", units: "− 12" },
  { ref: "IN/02479", type: "Receipt", partner: "Kinetic Components", location: "Overflow Bay", date: "Yesterday, 15:12", status: "Draft", units: "+ 480" },
];

const lowStock = [
  { name: "Stainless Steel Rods", sku: "STL-ROD-12", stock: "48 kg", reorder: "120 kg", color: "#f06b4d" },
  { name: "Industrial Bearings", sku: "BRG-6204-2Z", stock: "14 pcs", reorder: "40 pcs", color: "#e9a02f" },
  { name: "Safety Gloves · L", sku: "PPE-GLV-L", stock: "26 pairs", reorder: "80 pairs", color: "#f06b4d" },
];

const navGroups = [
  {
    label: "Workspace",
    items: [
      { label: "Dashboard", icon: LayoutDashboard },
      { label: "Products", icon: Package, count: "248" },
      { label: "Operations", icon: Boxes, hasChevron: true },
      { label: "Receipts", icon: ArrowDownLeft, count: "8" },
      { label: "Deliveries", icon: ArrowUpRight, count: "12" },
      { label: "Transfers", icon: Truck },
      { label: "Adjustments", icon: ClipboardCheck },
      { label: "Move history", icon: FileBarChart },
    ],
  },
  {
    label: "Manage",
    items: [
      { label: "Warehouses", icon: Warehouse },
      { label: "Team & access", icon: UsersRound },
      { label: "Settings", icon: Settings2 },
    ],
  },
];

function StatusPill({ status }: { status: Operation["status"] }) {
  const styles = {
    Waiting: "status-waiting",
    Ready: "status-ready",
    Done: "status-done",
    Draft: "status-draft",
  };
  return <span className={`status-pill ${styles[status]}`}><span className="status-dot" />{status}</span>;
}

function MiniSparkline({ positive = true }: { positive?: boolean }) {
  return (
    <svg className="mini-spark" viewBox="0 0 86 28" fill="none" aria-hidden="true">
      <path d={positive ? "M1 23C11 23 11 16 21 18C31 20 34 9 43 12C52 15 56 7 64 9C72 11 76 3 85 4" : "M1 5C11 5 11 12 21 10C31 8 34 18 43 16C52 13 56 20 64 18C72 16 76 24 85 23"} stroke={positive ? "#92c83e" : "#f06b4d"} strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}

function KpiCard({ icon: Icon, label, value, detail, trend, positive = true, tint }: { icon: typeof Package; label: string; value: string; detail: string; trend: string; positive?: boolean; tint: string }) {
  return (
    <div className="kpi-card">
      <div className="kpi-topline">
        <span className="kpi-icon" style={{ background: tint }}><Icon size={17} strokeWidth={2.2} /></span>
        <span className="kpi-label">{label}</span>
        <button className="icon-button subtle" onClick={() => toast(`${label} details are coming soon`)} aria-label={`View ${label} details`}><CircleHelp size={15} /></button>
      </div>
      <div className="kpi-value-row"><span className="kpi-value">{value}</span><MiniSparkline positive={positive} /></div>
      <div className="kpi-bottom"><span className={positive ? "trend-up" : "trend-down"}>{positive ? "↑" : "↓"} {trend}</span><span className="kpi-detail">{detail}</span></div>
    </div>
  );
}

function StockPulseChart() {
  const bars = [42, 56, 48, 68, 62, 74, 58, 81, 69, 88, 75, 92, 84, 96];
  return (
    <div className="pulse-chart-wrap">
      <div className="chart-y-labels"><span>4.5k</span><span>3k</span><span>1.5k</span><span>0</span></div>
      <div className="pulse-chart">
        <div className="chart-grid"><span /><span /><span /><span /></div>
        <svg className="chart-line" viewBox="0 0 680 190" preserveAspectRatio="none" aria-label="Stock pulse trend over the last 14 days" role="img">
          <defs><linearGradient id="pulseFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#c5e86c" stopOpacity=".38" /><stop offset="1" stopColor="#c5e86c" stopOpacity="0" /></linearGradient></defs>
          <path d="M0 148C30 142 28 120 54 125C82 131 78 100 108 106C140 112 130 86 162 95C194 104 194 64 226 77C258 89 255 98 284 77C314 54 321 84 348 68C376 51 373 39 405 57C436 75 438 43 465 53C491 62 495 83 522 66C552 47 566 77 590 53C615 28 640 53 680 27V190H0Z" fill="url(#pulseFill)" />
          <path d="M0 148C30 142 28 120 54 125C82 131 78 100 108 106C140 112 130 86 162 95C194 104 194 64 226 77C258 89 255 98 284 77C314 54 321 84 348 68C376 51 373 39 405 57C436 75 438 43 465 53C491 62 495 83 522 66C552 47 566 77 590 53C615 28 640 53 680 27" stroke="#a5cf53" strokeWidth="3" fill="none" strokeLinecap="round" />
          <circle cx="405" cy="57" r="5" fill="#fffdf7" stroke="#a5cf53" strokeWidth="3" /><circle cx="680" cy="27" r="5" fill="#fffdf7" stroke="#a5cf53" strokeWidth="3" />
        </svg>
        <div className="chart-bars">{bars.map((height, index) => <span key={index} style={{ height: `${height}%` }} />)}</div>
        <div className="chart-x-labels"><span>Sep 13</span><span>Sep 16</span><span>Sep 19</span><span>Sep 22</span><span>Sep 26</span></div>
      </div>
    </div>
  );
}

export default function Home() {
  const [, navigate] = useLocation();
  const [activeNav, setActiveNav] = useState("Dashboard");
  const [globalQuery, setGlobalQuery] = useState("");
  const [operationQuery, setOperationQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All status");
  const [locationFilter, setLocationFilter] = useState("All locations");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [quickPanelOpen, setQuickPanelOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [warehouseOpen, setWarehouseOpen] = useState(false);
  const [activeWarehouse, setActiveWarehouse] = useState(() => getActiveWarehouse());
  const storedUser = getStoredUser();
  const displayName = storedUser?.name || "Maya Rao";
  const initials = displayName.split(" ").map((part) => part[0]).join("").slice(0, 2).toUpperCase();

  useEffect(() => {
    if (!storedUser) navigate("/login");
  }, [navigate, storedUser]);

  const filteredOperations = useMemo(() => operations.filter((operation) => {
    const matchesQuery = `${operation.ref} ${operation.type} ${operation.partner} ${operation.location}`.toLowerCase().includes(operationQuery.toLowerCase());
    const matchesStatus = statusFilter === "All status" || operation.status === statusFilter;
    const matchesLocation = locationFilter === "All locations" || operation.location === locationFilter;
    return matchesQuery && matchesStatus && matchesLocation;
  }), [operationQuery, statusFilter, locationFilter]);

  const handleGlobalSearch = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key !== "Enter") return;
    const search = globalQuery.trim();
    if (!search) return;
    navigate(`/products?search=${encodeURIComponent(search)}`);
  };

  const handleNav = (label: string) => {
    setActiveNav(label);
    setMobileNavOpen(false);
    if (label === "Products") {
      navigate("/products");
      return;
    }
    if (label === "Transfers") {
      navigate("/transfers");
      return;
    }
    if (label === "Settings") {
      navigate("/settings");
      return;
    }
    if (label !== "Dashboard") toast(`${label} view is ready for your next workflow`);
  };

  const handleLogout = () => {
    clearStoredUser();
    toast.success("You have been logged out");
    navigate("/login");
  };

  const chooseWarehouse = (name: string) => {
    const warehouse = saveActiveWarehouse(name);
    setActiveWarehouse(warehouse);
    setWarehouseOpen(false);
    toast.success(`${warehouse.name} is now active`);
  };

  const downloadReport = () => {
    const rows = [
      ["Reference", "Type", "Partner / note", "Location", "Date", "Status", "Units"],
      ...operations.map((operation) => [operation.ref, operation.type, operation.partner, operation.location, operation.date, operation.status, operation.units]),
    ];
    const csv = rows.map((row) => row.map((value) => `"${value.replaceAll('"', '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `stocksense-operations-${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
    toast.success("Report downloaded");
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNavOpen ? "sidebar-open" : ""}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><span /><span /><span /></div>
          <div><div className="brand-name">stocksense</div><div className="brand-sub">Inventory operating system</div></div>
          <button className="mobile-close icon-button" onClick={() => setMobileNavOpen(false)} aria-label="Close navigation"><X size={18} /></button>
        </div>

        <div className="warehouse-switcher-wrap">
          <div className="warehouse-switcher" onClick={() => setWarehouseOpen((value) => !value)} role="button" tabIndex={0} aria-expanded={warehouseOpen}>
            <span className="warehouse-avatar"><Warehouse size={16} /></span>
            <span className="warehouse-copy"><strong>{activeWarehouse.name}</strong><small>{activeWarehouse.city} · Active</small></span>
            <ChevronDown size={15} className="muted-icon" />
          </div>
          {warehouseOpen && <div className="warehouse-menu">{warehouses.map((warehouse) => <button key={warehouse.name} className={warehouse.name === activeWarehouse.name ? "selected" : ""} onClick={() => chooseWarehouse(warehouse.name)}><span className="warehouse-menu-icon"><Warehouse size={14} /></span><span><strong>{warehouse.name}</strong><small>{warehouse.city}</small></span>{warehouse.name === activeWarehouse.name && <span className="warehouse-check">✓</span>}</button>)}</div>}
        </div>

        <nav className="side-nav" aria-label="Primary navigation">
          {navGroups.map((group) => <div className="nav-group" key={group.label}>
            <div className="nav-group-label">{group.label}</div>
            {group.items.map(({ label, icon: Icon, count, hasChevron }) => <button key={label} className={`nav-item ${activeNav === label ? "active" : ""}`} onClick={() => handleNav(label)}>
              <Icon size={17} strokeWidth={activeNav === label ? 2.4 : 1.9} /><span>{label}</span>{count && <em>{count}</em>}{hasChevron && <ChevronDown size={14} className="nav-chevron" />}
            </button>)}
          </div>)}
        </nav>

        <div className="sidebar-footer">
          <div className="help-card"><div className="help-orbit"><LifeBuoy size={17} /></div><div><strong>Need a hand?</strong><span>Visit the knowledge base</span></div><ArrowUpRight size={14} /></div>
          <div className="profile-row"><div className="avatar">{initials}</div><div className="profile-copy"><strong>{displayName}</strong><span>{storedUser?.email || "Inventory manager"}</span></div><button className="logout-button" onClick={handleLogout} aria-label="Log out"><LogOut size={15} /></button></div>
        </div>
      </aside>

      {mobileNavOpen && <button className="mobile-backdrop" onClick={() => setMobileNavOpen(false)} aria-label="Close navigation overlay" />}

      <main className="main-area">
        <header className="topbar">
          <button className="mobile-menu icon-button" onClick={() => setMobileNavOpen(true)} aria-label="Open navigation"><Menu size={20} /></button>
          <div className="breadcrumbs"><span>Workspace</span><span className="crumb-separator">/</span><strong>{activeNav}</strong></div>
          <div className="topbar-actions">
            <label className="global-search"><Search size={17} /><input placeholder="Search products or SKUs" value={globalQuery} onChange={(event) => setGlobalQuery(event.target.value)} onKeyDown={handleGlobalSearch} aria-label="Search products or SKUs" /><kbd>⌘ K</kbd></label>
            <div className="notification-wrap"><button className={`icon-button notification-button ${notificationOpen ? "active" : ""}`} onClick={() => setNotificationOpen((value) => !value)} aria-label="View notifications" aria-expanded={notificationOpen}><Bell size={18} /><span className="notification-dot" /></button>{notificationOpen && <div className="notification-popover"><div className="notification-heading"><div><strong>Alerts</strong><small>2 items need attention</small></div><button onClick={() => setNotificationOpen(false)} aria-label="Close notifications"><X size={15} /></button></div><div className="notification-item"><span className="notification-icon danger"><Package size={15} /></span><span><strong>3 SKUs below reorder point</strong><small>Review low stock across your warehouses.</small></span><button onClick={() => { setNotificationOpen(false); navigate("/products?stock=low"); }}>Review</button></div><div className="notification-item"><span className="notification-icon warning"><Truck size={15} /></span><span><strong>2 transfers are waiting</strong><small>Keep today’s stock movement on track.</small></span><button onClick={() => { setNotificationOpen(false); navigate("/transfers?status=Ready"); }}>Open</button></div><div className="notification-footer"><button onClick={() => { setNotificationOpen(false); toast.success("All alerts marked as read"); }}>Mark all as read</button></div></div>}</div>
            <div className="topbar-avatar">{initials}</div><button className="icon-button topbar-logout" onClick={handleLogout} aria-label="Log out"><LogOut size={16} /></button>
          </div>
        </header>

        <div className="content-wrap">
          <section className="welcome-row page-enter">
            <div><div className="eyebrow"><span className="live-pulse" /> Friday, September 26, 2026</div><h1>Good morning, {displayName.split(" ")[0]}<span className="heading-period">.</span></h1><p>Here’s what’s moving across your inventory today.</p></div>
            <div className="welcome-actions"><button className="secondary-button" onClick={downloadReport}> <FileBarChart size={16} /> Export report</button><button className="primary-button" onClick={() => setQuickPanelOpen(true)}><Plus size={17} /> New operation</button></div>
          </section>

          <section className="kpi-grid page-enter delay-1" aria-label="Inventory key performance indicators">
            <KpiCard icon={Package} label="Total in stock" value="24,680" detail="units across 4 locations" trend="8.4% vs last month" tint="#e7f1c7" />
            <KpiCard icon={Zap} label="Low / out of stock" value="18" detail="need your attention" trend="3 more this week" positive={false} tint="#fbe3d9" />
            <KpiCard icon={ArrowDownLeft} label="Pending receipts" value="08" detail="1,720 units expected" trend="2 due today" tint="#e4e8fa" />
            <KpiCard icon={ArrowUpRight} label="Pending deliveries" value="12" detail="486 units to dispatch" trend="4 ready to pick" tint="#f6e7bc" />
          </section>

          <section className="primary-grid page-enter delay-2">
            <div className="panel pulse-panel">
              <div className="panel-header"><div><div className="panel-kicker">Inventory pulse</div><h2>Stock movement</h2></div><div className="period-toggle"><button className="selected">14 days</button><button onClick={() => toast("30 day view coming soon")}>30 days</button><button onClick={() => toast("90 day view coming soon")}>90 days</button></div></div>
              <div className="pulse-meta"><div><span className="pulse-number">4,286</span><span className="pulse-unit">units moved</span></div><span className="pulse-change"><ArrowUpRight size={14} /> 12.6%</span><span className="pulse-caption">vs previous period</span></div>
              <StockPulseChart />
            </div>

            <div className="panel attention-panel">
              <div className="panel-header"><div><div className="panel-kicker accent-kicker">Needs attention</div><h2>Low stock watchlist</h2></div><button className="text-button" onClick={() => handleNav("Products")}>View all <ArrowUpRight size={14} /></button></div>
              <div className="attention-list">{lowStock.map((item) => <div className="attention-item" key={item.sku}><div className="stock-item-icon" style={{ background: `${item.color}18`, color: item.color }}><Package size={17} /></div><div className="attention-copy"><strong>{item.name}</strong><span>{item.sku}</span></div><div className="stock-amount"><strong>{item.stock}</strong><span>of {item.reorder}</span></div><div className="stock-bar"><span style={{ width: item.stock.includes("48") ? "40%" : item.stock.includes("14") ? "28%" : "33%", background: item.color }} /></div></div>)}</div>
              <button className="restock-button" onClick={() => navigate("/products?stock=low")}> <Sparkles size={15} /> Review low-stock SKUs</button>
            </div>
          </section>

          <section className="panel operations-panel page-enter delay-3">
            <div className="panel-header operations-header"><div><div className="panel-kicker">Live operations</div><h2>Recent activity</h2></div><div className="operation-tools"><div className="filter-search"><Search size={15} /><input value={operationQuery} onChange={(event) => setOperationQuery(event.target.value)} placeholder="Filter operations" aria-label="Filter operations" /></div><div className="select-wrap"><Filter size={14} /><select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} aria-label="Filter by status"><option>All status</option><option>Waiting</option><option>Ready</option><option>Done</option><option>Draft</option></select><ChevronDown size={13} /></div><div className="select-wrap location-select"><MapPin size={14} /><select value={locationFilter} onChange={(event) => setLocationFilter(event.target.value)} aria-label="Filter by location"><option>All locations</option><option>Main Warehouse</option><option>Overflow Bay</option><option>Rack A → Line 3</option></select><ChevronDown size={13} /></div><button className="icon-button filter-button" onClick={() => toast("Advanced filters opened")} aria-label="Open advanced filters"><SlidersHorizontal size={16} /></button></div></div>
            <div className="mobile-filter-label"><ListFilter size={14} /> Filters update this activity view in real time</div>
            <div className="table-wrap"><table><thead><tr><th>Reference</th><th>Type</th><th>Partner / note</th><th>Location</th><th>Date</th><th>Status</th><th className="units-col">Units</th><th /></tr></thead><tbody>{filteredOperations.map((operation) => <tr key={operation.ref}><td><button className="ref-link" onClick={() => toast(`${operation.ref} details opened`)}>{operation.ref}</button></td><td><span className={`type-mark type-${operation.type.toLowerCase()}`}><span />{operation.type}</span></td><td><strong className="partner-name">{operation.partner}</strong></td><td><span className="table-location"><MapPin size={13} />{operation.location}</span></td><td><span className="date-text">{operation.date}</span></td><td><StatusPill status={operation.status} /></td><td className={`units ${operation.units.startsWith("−") ? "negative" : operation.units.startsWith("+") ? "positive" : ""}`}>{operation.units}</td><td><button className="row-more" onClick={() => toast(`${operation.ref} actions opened`)} aria-label={`More actions for ${operation.ref}`}>•••</button></td></tr>)}</tbody></table>{filteredOperations.length === 0 && <div className="empty-state"><Search size={18} /><strong>No operations found</strong><span>Try a different search or filter combination.</span></div>}</div>
            <div className="table-footer"><span>Showing <strong>{filteredOperations.length}</strong> of 32 operations</span><button className="text-button" onClick={() => handleNav("Move history")}>Open move history <ArrowUpRight size={14} /></button></div>
          </section>

          <footer className="page-footer"><span><ShieldCheck size={14} /> Data synced just now</span><span>StockSense v1.0 · <button onClick={() => toast("Help center opened")}>Help center</button></span></footer>
        </div>
      </main>

      {quickPanelOpen && <div className="drawer-backdrop" onClick={() => setQuickPanelOpen(false)}><section className="quick-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-top"><div><div className="panel-kicker accent-kicker">Quick create</div><h2>Start an operation</h2><p>Choose a workflow to keep stock moving.</p></div><button className="icon-button" onClick={() => setQuickPanelOpen(false)} aria-label="Close quick create"><X size={18} /></button></div><div className="quick-actions"><button onClick={() => { toast.success("New receipt started"); setQuickPanelOpen(false); }}><span className="quick-icon receipt"><ArrowDownLeft size={18} /></span><span><strong>New receipt</strong><small>Log incoming goods from a vendor</small></span><ArrowUpRight size={15} /></button><button onClick={() => { toast.success("New delivery started"); setQuickPanelOpen(false); }}><span className="quick-icon delivery"><ArrowUpRight size={18} /></span><span><strong>New delivery</strong><small>Prepare an outgoing shipment</small></span><ArrowUpRight size={15} /></button><button onClick={() => { toast.success("Transfer workflow started"); setQuickPanelOpen(false); }}><span className="quick-icon transfer"><Truck size={18} /></span><span><strong>Internal transfer</strong><small>Move stock between locations</small></span><ArrowUpRight size={15} /></button><button onClick={() => { toast.success("Adjustment workflow started"); setQuickPanelOpen(false); }}><span className="quick-icon adjustment"><ClipboardCheck size={18} /></span><span><strong>Stock adjustment</strong><small>Reconcile a physical count</small></span><ArrowUpRight size={15} /></button></div><div className="drawer-note"><Sparkles size={15} /><span>Every action is logged automatically in the stock ledger.</span></div></section></div>}
    </div>
  );
}
