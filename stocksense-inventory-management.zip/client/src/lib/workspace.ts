export const warehouses = [
  { name: "Main Warehouse", city: "New Delhi", code: "MW" },
  { name: "Overflow Bay", city: "Gurugram", code: "OB" },
  { name: "Production Floor", city: "Noida", code: "PF" },
];

const WAREHOUSE_KEY = "stocksense.activeWarehouse";

export function getActiveWarehouse() {
  if (typeof window === "undefined") return warehouses[0];
  const saved = window.localStorage.getItem(WAREHOUSE_KEY);
  return warehouses.find((warehouse) => warehouse.name === saved) ?? warehouses[0];
}

export function saveActiveWarehouse(name: string) {
  const warehouse = warehouses.find((item) => item.name === name) ?? warehouses[0];
  window.localStorage.setItem(WAREHOUSE_KEY, warehouse.name);
  return warehouse;
}
