export type RegisteredUser = {
  name: string;
  email: string;
  createdAt: string;
};

const USER_KEY = "stocksense.user";

export function getStoredUser(): RegisteredUser | null {
  try {
    const value = window.localStorage.getItem(USER_KEY);
    return value ? (JSON.parse(value) as RegisteredUser) : null;
  } catch {
    return null;
  }
}

export function saveStoredUser(user: RegisteredUser) {
  window.localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function clearStoredUser() {
  window.localStorage.removeItem(USER_KEY);
}
