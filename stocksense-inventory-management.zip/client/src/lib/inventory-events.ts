export type InventoryAlertStatus = "Low stock" | "Out of stock";

export type InventoryThresholdEvent = {
  id: string;
  name: string;
  sku: string;
  stock: number;
  reorder: number;
  uom: string;
  location: string;
  status: InventoryAlertStatus;
  createdAt: string;
};

export const INVENTORY_EVENT = "stocksense:inventory-threshold";
const STORAGE_KEY = "stocksense.latestInventoryThreshold";

export function publishInventoryThreshold(event: Omit<InventoryThresholdEvent, "id" | "createdAt">) {
  if (typeof window === "undefined") return;
  const payload: InventoryThresholdEvent = {
    ...event,
    id: `${event.sku}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
  };
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  window.dispatchEvent(new CustomEvent<InventoryThresholdEvent>(INVENTORY_EVENT, { detail: payload }));
}

export function parseInventoryThreshold(value: string | null): InventoryThresholdEvent | null {
  if (!value) return null;
  try {
    const parsed = JSON.parse(value) as InventoryThresholdEvent;
    if (!parsed.id || !parsed.name || !parsed.sku || !parsed.status) return null;
    return parsed;
  } catch {
    return null;
  }
}
