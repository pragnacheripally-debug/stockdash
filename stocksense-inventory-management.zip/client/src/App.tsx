import { useEffect } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import { toast } from "sonner";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import Products from "./pages/Products";
import Register from "./pages/Register";
import Settings from "./pages/Settings";
import Transfers from "./pages/Transfers";
import { INVENTORY_EVENT, parseInventoryThreshold, type InventoryThresholdEvent } from "./lib/inventory-events";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/products" component={Products} />
      <Route path="/register" component={Register} />
      <Route path="/settings" component={Settings} />
      <Route path="/transfers" component={Transfers} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function InventoryAlertListener() {
  useEffect(() => {
    const showAlert = (event: InventoryThresholdEvent) => {
      const amount = `${event.stock.toLocaleString()} ${event.uom} on hand against a ${event.reorder.toLocaleString()} ${event.uom} reorder point`;
      toast.warning(`${event.status}: ${event.name}`, {
        description: `${event.sku} · ${event.location} · ${amount}`,
        duration: 8500,
      });
    };
    const handleCustomEvent = (event: Event) => {
      const detail = (event as CustomEvent<InventoryThresholdEvent>).detail;
      if (detail) showAlert(detail);
    };
    const handleStorage = (event: StorageEvent) => {
      const detail = parseInventoryThreshold(event.newValue);
      if (event.key === "stocksense.latestInventoryThreshold" && detail) showAlert(detail);
    };
    window.addEventListener(INVENTORY_EVENT, handleCustomEvent);
    window.addEventListener("storage", handleStorage);
    return () => {
      window.removeEventListener(INVENTORY_EVENT, handleCustomEvent);
      window.removeEventListener("storage", handleStorage);
    };
  }, []);
  return null;
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster position="bottom-right" />
          <InventoryAlertListener />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
